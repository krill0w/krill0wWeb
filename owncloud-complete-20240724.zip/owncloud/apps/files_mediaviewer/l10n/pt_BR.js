OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Fechar",
    "Download" : "Baixar",
    "Fullscreen" : "Tela cheia",
    "Loading" : "Carregando",
    "Mute" : "Mudar",
    "Next" : "Próximo",
    "of" : "de",
    "Play" : "Executar",
    "Previous" : "Anterior",
    "Replay" : "Responder",
    "Rotate 90° counterclockwise" : "Rotacionar 90º no sentido dos ponteiros do relógio",
    "Zoom in" : "Ampliar",
    "Zoom out" : "Diminuir",
    "Open in Media Viewer" : "Abrir no Visualizador de Mídia"
},
"nplurals=2; plural=(n > 1);");
