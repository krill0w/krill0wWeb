OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "ปิด",
    "Download" : "ดาวน์โหลด",
    "Fullscreen" : "เต็มจอ",
    "Loading" : "กำลังโหลด",
    "Mute" : "เงียบ",
    "Next" : "ต่อไป",
    "of" : "ของ",
    "Play" : "เล่น",
    "Previous" : "ก่อนหน้า",
    "Replay" : "เล่นใหม่",
    "Rotate 90° counterclockwise" : "หมุนทวนเข็ม 90°",
    "Zoom in" : "ซูมเข้า",
    "Zoom out" : "ซูมออก"
},
"nplurals=1; plural=0;");
