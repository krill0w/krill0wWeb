OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Κλείσιμο",
    "Download" : "Λήψη",
    "Fullscreen" : "Πλήρης οθόνη",
    "Loading" : "Γίνεται φόρτωση",
    "Mute" : "Σίγαση",
    "Next" : "Επόμενο",
    "of" : "του",
    "Play" : "Αναπαραγωγή",
    "Previous" : "Προηγούμενο",
    "Replay" : "Επανάληψη",
    "Rotate 90° counterclockwise" : "Περιστροφή 90° αριστερόστροφα",
    "Zoom in" : "Μεγέθυνση",
    "Zoom out" : "Σμίκρυνση"
},
"nplurals=2; plural=(n != 1);");
