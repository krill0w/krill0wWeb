OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Schliessen",
    "Download" : "Herunterladen",
    "Fullscreen" : "Vollbildschirm",
    "Loading" : "Lade",
    "Mute" : "Ton aus",
    "Next" : "Weiter",
    "of" : "von",
    "Play" : "Abspielen",
    "Previous" : "Zurück",
    "Replay" : "Wiedergeben",
    "Rotate 90° counterclockwise" : "Um 90° im Uhrzeigersinn drehen",
    "Zoom in" : "Vergrössern",
    "Zoom out" : "Verkleinern",
    "Open in Media Viewer" : "Mit Media Viewer öffnen"
},
"nplurals=2; plural=(n != 1);");
