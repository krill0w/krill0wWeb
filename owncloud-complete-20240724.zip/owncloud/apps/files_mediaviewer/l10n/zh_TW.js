OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "關閉",
    "Download" : "下載",
    "Fullscreen" : "全螢幕",
    "Loading" : "載入中",
    "Mute" : "靜音",
    "Next" : "下一個",
    "of" : "的",
    "Play" : "播放",
    "Previous" : "上一個",
    "Replay" : "重播",
    "Rotate 90° counterclockwise" : "逆時針旋轉 90°",
    "Zoom in" : "放大",
    "Zoom out" : "縮小"
},
"nplurals=1; plural=0;");
