OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Sulge",
    "Download" : "Laadi alla",
    "Fullscreen" : "äisekraanil",
    "Loading" : "Laadimine",
    "Mute" : "Vaigista",
    "Next" : "Järgmine",
    "Play" : "Esita",
    "Previous" : "Eelmine",
    "Replay" : "Esita uuesti"
},
"nplurals=2; plural=(n != 1);");
