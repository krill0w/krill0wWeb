OC.L10N.register(
    "firstrunwizard",
    {
    "Get the apps to sync your files" : "Fayllarınızın sinxronizasiyası üçün proqramları götürün",
    "Desktop client" : "Desktop client",
    "Android app" : "Android proqramı",
    "iOS app" : "iOS proqramı",
    "Connect your desktop apps to %s" : "Desktop proqramınızı %s-ə qoşun",
    "Connect your Calendar" : "Öz kalendarınıza qoşulun",
    "Connect your Contacts" : "Əlaqələri qoşun",
    "Documentation" : "Sənədlər",
    "Access files via WebDAV" : "Fayllara WebDAV ilə yetki",
    "There’s more information in the <a target=\"_blank\" href=\"%s\">documentation</a> and on our <a target=\"_blank\" href=\"http://owncloud.org\">website</a>." : "Orda çoxlu informasiya var <a target=\"_blank\" href=\"%s\">sənədləşmədə</a> və bizim <a target=\"_blank\" href=\"http://owncloud.org\">web səhifədə</a>."
},
"nplurals=2; plural=(n != 1);");
