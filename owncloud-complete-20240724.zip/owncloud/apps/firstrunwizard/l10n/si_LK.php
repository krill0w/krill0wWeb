<?php
$TRANSLATIONS = array(
"Documentation" => "ලේඛන"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
